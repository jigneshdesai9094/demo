package EduSell.service;

import EduSell.dto.UserRegisterDto;
import EduSell.dto.VerificationDTO;
import EduSell.helper.OtpData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;


import java.time.LocalDateTime;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class EmailOtpService {
    @Autowired
    private JavaMailSender javaMailSender;

    @Value("${spring.mail.username}")
    private String mailUsername;

    private final Map<String, OtpData> otpStore = new ConcurrentHashMap<>();
    private final Map<String,UserRegisterDto> pendingRegistraction= new ConcurrentHashMap<>();

    public Long generateOtp()
    {
        System.out.println(Math.random()*1000000);
        Long otp = (long) Math.ceil(Math.random() * 1000000);
        return otp;
    }

    public void sendOtp(UserRegisterDto dto)
    {
        Long otp = generateOtp();

        pendingRegistraction.put(dto.getEmail(),dto);

        otpStore.put(dto.getEmail(),new OtpData(otp, LocalDateTime.now().plusMinutes(5)));
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(mailUsername); // Replace with your email

        message.setTo(dto.getEmail());
        message.setSubject("Your OTP Code");
        message.setText("Your OTP code is: " + otp + "\nThis code is valid for 5 minutes.");
        javaMailSender.send(message);

    }

    public UserRegisterDto verifyOtp(VerificationDTO verificationDTO) throws Exception {
        OtpData otpData = otpStore.get(verificationDTO.getEmail());

        if(otpData == null)
        {
            throw  new Exception("please, try again");
        }

        else if(Objects.equals(otpData.getOtp(), verificationDTO.getOtp()) && LocalDateTime.now().isBefore(otpData.getExpiryTime()))
        {
            return  pendingRegistraction.get(verificationDTO.getEmail());
        }
        if(LocalDateTime.now().isAfter(otpData.getExpiryTime()))
            throw new Exception("otp time expire , please regenrate otp");
        throw   new Exception("otp not match , please enter correct otp");
    }
}
