//package EduSell.model;
//
//import jakarta.persistence.*;
//import lombok.*;
//import java.math.BigDecimal;
//import java.time.LocalDate;
//
//@Entity
//@Table(name = "Purchases")
//@Data
//@NoArgsConstructor
//@AllArgsConstructor
//public class Purchase {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Integer purchaseId;
//
//    @ManyToOne
//    @JoinColumn(name = "UserID", nullable = false)
//    private User user;
//
//    @ManyToOne
//    @JoinColumn(name = "CourseID", nullable = false)
//    private Course course;
//
//    @Column(name = "PurchaseDate", nullable = false)
//    private LocalDate purchaseDate;
//
//    @Column(name = "ExpirationDate", nullable = false)
//    private LocalDate expirationDate;
//
//    @Column(name = "Amount", nullable = false, precision = 10, scale = 2)
//    private BigDecimal amount;
//
//    @PrePersist
//    protected void onCreate() {
//        if (purchaseDate == null) {
//            purchaseDate = LocalDate.now();
//        }
//    }
//}
