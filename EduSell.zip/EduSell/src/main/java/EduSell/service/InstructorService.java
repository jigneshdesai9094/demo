package EduSell.service;


import EduSell.dto.UserRegisterDto;
import EduSell.model.Role;
import EduSell.model.User;
import EduSell.repository.RoleRepository;
import EduSell.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InstructorService {

     @Autowired
     private UserRepository userRepository;

     @Autowired
     private RoleRepository roleRepository;

     @Autowired
     private ModelMapper modelMapper;

     public String register(UserRegisterDto dto)
     {
         // Validate roleId is 1 (ROLE_INSTRUCTOR)
         if (dto.getRoleId() != 1) {
             throw new IllegalArgumentException("Role ID must be 1 for Instructor registration");
         }

         // Validate uniqueness of email and username (since no UNIQUE constraints)
         if (userRepository.existsByEmail(dto.getEmail())) {
             throw new IllegalArgumentException("Email already exists");
         }
         if (userRepository.existsByUsername(dto.getUsername())) {
             throw new IllegalArgumentException("Username already exists");
         }

         if (userRepository.existsByMobileNo(dto.getMobileNo())) {
             throw new IllegalArgumentException("Mobile number already exists");
         }

         User user =  modelMapper.map(dto, User.class);

         Optional<Role> optionalRole = roleRepository.findById(dto.getRoleId());

         Role role = optionalRole.get();

         role.getUsers().add(user);

         user.getRoles().add(role);

         roleRepository.save(role);

         userRepository.save(user);

         return  "register successfully";
     }
}
