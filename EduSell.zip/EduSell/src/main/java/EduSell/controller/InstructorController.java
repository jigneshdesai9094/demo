package EduSell.controller;

import EduSell.dto.BankAccountDTO;
import EduSell.model.BankAccount;
import EduSell.repository.BankAccountRepository;
import EduSell.service.InstructorService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/instructor")
public class InstructorController {

    @Autowired
    private InstructorService instructorService;

    @Autowired
    private BankAccountRepository bankAccountRepository;

    @PostMapping("/bank-account")
    public ResponseEntity<?> addBankAccount(@Valid @RequestBody BankAccountDTO bankAccountDTO)
    {
        try {
           String msg =  instructorService.addBankAccount(bankAccountDTO);
            return  new ResponseEntity<>(msg, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
        }
    }


}
