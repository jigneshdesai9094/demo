package EduSell.service;

import EduSell.dto.BankAccountDTO;
import EduSell.model.BankAccount;
import EduSell.model.User;
import EduSell.repository.BankAccountRepository;
import EduSell.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InstructorService {

    @Autowired
    private BankAccountRepository bankAccountRepository;

    @Autowired
    private UserRepository userRepository;

    public String addBankAccount(BankAccountDTO bankAccountDTO) throws Exception {
        if(bankAccountRepository.existsByBankAccountNumber(bankAccountDTO.getBankAccountNumber())) {
            throw new Exception("already account is exists ");
        }
        System.out.println("service add bank account is call");
            BankAccount bankAccount = new BankAccount();
            bankAccount.setAccountHolderName(bankAccountDTO.getAccountHolderName());
            bankAccount.setBankAccountNumber(bankAccountDTO.getBankAccountNumber());
            bankAccount.setIfscCode(bankAccountDTO.getIfscCode());
            Optional<User> userOptional = userRepository.findById(bankAccountDTO.getUserId());
            User user = userOptional.get();
        System.out.println("in service method get user ready");
        System.out.println(user.getEmail() +" "+user.getUsername());
            bankAccount.setInstructor(user);

        System.out.println("in server add bank also complete here");
            bankAccountRepository.save(bankAccount);
            return "Bank account added successfully";

    }
}
